package g

const (
	VERSION = "0.0.1"
)
